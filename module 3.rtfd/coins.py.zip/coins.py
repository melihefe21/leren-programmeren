# name of student: melihefe erdogan
# number of student: 99071315
# purpose of program: calculating the change you get and give
# function of program:counting the change that needs to be given
# structure of program: recieve inputs from user to determin how much you get

toPay = int(float(input('Amount to pay: '))* 100) # user input * 100
paid = int(float(input('Paid amount: ')) * 100) # user input * 100
change = paid - toPay # counts how much change you need to get
returned = {}

if change > 0: # if it's a larger amount than 0 it begins the counting program
  coinValue = 50 # 
  
  while change > 0 and coinValue > 0: # looping the program until you have 0
    nrCoins = change // coinValue # floor division

    if nrCoins > 0: # how many coins yopu have
      print('return maximal ', nrCoins, ' coins of ', coinValue, ' cents!' ) # how much you can get
      nrCoinsReturned = int(input('How many coins of ' + str(coinValue) +  ' cents did you return? ')) # how much you returned
      change -= nrCoinsReturned * coinValue # chance - coins
      returned[coinValue] = nrCoinsReturned
# comment on code below: prints how many coins you can get off every kind
    if coinValue == 500:
      coinValue = 200
    elif coinValue == 200:
      coinValue = 100
    elif coinValue == 100:
      coinValue = 50
    elif coinValue == 50:
      coinValue = 20
    elif coinValue == 20:
        coinValue == 10
    elif coinValue == 10:
        coinValue = 5
    elif coinValue == 5:
      coinValue = 2
    elif coinValue == 2:
      coinValue = 1
    else:
      coinValue = 0
print(returned)
if change > 0: # then he doesn't get his chance
  print('Change not returned: ', str(change) + ' cents')
else:
  print('done')